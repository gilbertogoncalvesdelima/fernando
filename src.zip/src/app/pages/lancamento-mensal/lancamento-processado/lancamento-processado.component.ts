import { CommonModule } from '@angular/common';
import { Component, NgModule, ViewEncapsulation, ViewChild, AfterViewInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { EditModalComponent } from '../../lancamento-mensal/lancamento-processado/edit-modal/edit-modal.component';

interface DataItem {
  emp: string;
  data: string;
  valor: string;
  tp: string;
  agencia: string;
  produto: string;
  grupo: string;
  cenape: string;
  quantidade: number;
}

@Component({
  selector: 'app-lancamento-processado',
  templateUrl: './lancamento-processado.component.html',
  styleUrls: ['./lancamento-processado.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LancamentoProcessadoComponent implements AfterViewInit {
  displayedColumns: string[] = [
    'emp',
    'data',
    'valor',
    'tp',
    'agencia',
    'produto',
    'grupo',
    'cenape',
    'quantidade'
  ];

  dataSource = new MatTableDataSource<DataItem>([
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10 },
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15 },
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7 },
    { emp: '004', data: '2024-12-04', valor: '150,00', tp: 'Débito', agencia: '003', produto: 'D', grupo: 'G1', cenape: '101', quantidade: 3 },
    { emp: '005', data: '2024-12-05', valor: '200,00', tp: 'Crédito', agencia: '004', produto: 'E', grupo: 'G2', cenape: '654', quantidade: 8 },
    { emp: '006', data: '2024-12-06', valor: '300,00', tp: 'Débito', agencia: '006', produto: 'F', grupo: 'G3', cenape: '852', quantidade: 20 },
    { emp: '007', data: '2024-12-07', valor: '50,00', tp: 'Crédito', agencia: '007', produto: 'A', grupo: 'G1', cenape: '963', quantidade: 5 },
    { emp: '008', data: '2024-12-08', valor: '120,00', tp: 'Débito', agencia: '008', produto: 'B', grupo: 'G2', cenape: '357', quantidade: 4 },
    { emp: '009', data: '2024-12-09', valor: '175,00', tp: 'Crédito', agencia: '009', produto: 'C', grupo: 'G3', cenape: '159', quantidade: 12 },
    { emp: '010', data: '2024-12-10', valor: '220,00', tp: 'Débito', agencia: '010', produto: 'D', grupo: 'G1', cenape: '753', quantidade: 6 },
    { emp: '011', data: '2024-12-11', valor: '90,00', tp: 'Crédito', agencia: '011', produto: 'E', grupo: 'G2', cenape: '111', quantidade: 9 },
    { emp: '012', data: '2024-12-12', valor: '300,00', tp: 'Débito', agencia: '012', produto: 'F', grupo: 'G3', cenape: '222', quantidade: 13 },
    { emp: '013', data: '2024-12-13', valor: '400,00', tp: 'Crédito', agencia: '013', produto: 'A', grupo: 'G1', cenape: '333', quantidade: 11 },
    { emp: '014', data: '2024-12-14', valor: '350,00', tp: 'Débito', agencia: '014', produto: 'B', grupo: 'G2', cenape: '444', quantidade: 14 },
    { emp: '015', data: '2024-12-15', valor: '125,00', tp: 'Crédito', agencia: '015', produto: 'C', grupo: 'G3', cenape: '555', quantidade: 2 }
]);

  @ViewChild(MatSort) sort!: MatSort;

  totalDebito = '0,00';
  totalCredito = '0,00';
  searchValue: string = '';

  constructor(private dialog: MatDialog) {
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'valor':
          return parseFloat(item.valor.replace(',', '.'));
        case 'data':
          return new Date(item.data).getTime();
        default:
          return (item as any)[property]?.toString().toLowerCase() || '';
      }
    };
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  applyFilter() {
    this.dataSource.filter = this.searchValue.trim().toLowerCase();
  }

  editRow(row: DataItem) {
    const dialogRef = this.dialog.open(EditModalComponent, {
      width: '400px',
      data: row,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log('Dialog closed with result:', result);
      }
    });
  }
}

@NgModule({
  declarations: [LancamentoProcessadoComponent, EditModalComponent],
  imports: [
    CommonModule,
    MatRadioModule,
    MatButtonModule,
    MatTableModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatOptionModule,
    MatToolbarModule,
    MatDialogModule,
    MatSortModule,
    FormsModule
  ],
  exports: [LancamentoProcessadoComponent],
})
export class LancamentoProcessadoComponentModule {}
