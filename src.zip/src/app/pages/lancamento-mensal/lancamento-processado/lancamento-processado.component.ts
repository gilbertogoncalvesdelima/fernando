import { CommonModule } from '@angular/common';
import { Component, NgModule, ViewEncapsulation, ViewChild, AfterViewInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatCardModule } from '@angular/material/card';

interface DataItem {
  emp: string;
  data: string;
  valor: string;
  tp: string;
  agencia: string;
  produto: string;
  grupo: string;
  cenape: string;
  quantidade: number;
}

@Component({
  selector: 'app-lancamento-processado',
  templateUrl: './lancamento-processado.component.html',
  styleUrls: ['./lancamento-processado.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LancamentoProcessadoComponent implements AfterViewInit {
  displayedColumns: string[] = [
    'emp',
    'data',
    'valor',
    'tp',
    'agencia',
    'produto',
    'grupo',
    'cenape',
    'quantidade'
  ];

  dataSource = new MatTableDataSource<DataItem>([
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10 },
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15 },
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7 },
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10 },
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15 },
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7 },
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10 },
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15 },
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7 },
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10 },
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15 },
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7 },
  ]);

  @ViewChild(MatSort) sort!: MatSort;

  searchValue: string = '';
  mesAno: string = '';
  cnap: string = '';
  situacao: string = '';

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  applySpecificFilters() {
    this.dataSource.filterPredicate = (data: DataItem, filter: string) => {
      const mesAnoMatch = this.mesAno ? data.data.startsWith(this.mesAno) : true;
      const cnapMatch = this.cnap ? data.cenape.includes(this.cnap) : true;
      const situacaoMatch = this.situacao
        ? data.produto.toLowerCase().includes(this.situacao.toLowerCase())
        : true;
      return mesAnoMatch && cnapMatch && situacaoMatch;
    };
    this.dataSource.filter = JSON.stringify({
      mesAno: this.mesAno,
      cnap: this.cnap,
      situacao: this.situacao.toLowerCase(),
    });
  }

  applyGlobalSearch() {
    this.dataSource.filterPredicate = (data: DataItem, filter: string) =>
      Object.values(data).some((value) =>
        value.toString().toLowerCase().includes(filter)
      );
    this.dataSource.filter = this.searchValue.trim().toLowerCase();
  }
}

@NgModule({
  declarations: [LancamentoProcessadoComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatSortModule,
    MatCardModule,
    FormsModule,
  ],
  exports: [LancamentoProcessadoComponent],
})
export class LancamentoProcessadoComponentModule {}
