import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContainerModule } from '../shared/components/container/container.module';
import { ProdutosComponent } from './produtos/produtos.component';
import { TipoProdutoComponent } from './produtos/tipo-produto/tipo-produto.component';
import { CarteiraProdutoComponent } from './produtos/carteira-produtos/carteira-produtos.component';
import { AgrupamentoProdutosComponent } from './produtos/agrupamento-produtos/agrupamento-produtos.component';
import { AgrupamentoEmpresasComponent } from './produtos/agrupamento-empresas/agrupamento-empresas.component';
import { GrupoProducaoComponent } from './produtos/grupo-producao/grupo-producao.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { LancamentoManualFilterComponent } from './lancamento-manual/lancamento-manual-filter/lancamento-manual-filter.component';
import { LancamentoManualTableComponentModule } from './lancamento-manual/lancamento-manual-table/lancamento-manual-table.component';
import { LancamentoManualComponent } from './lancamento-manual/lancamento-manual.component';

@NgModule({
  declarations: [
    ProdutosComponent,
    TipoProdutoComponent,
    CarteiraProdutoComponent,
    AgrupamentoProdutosComponent,
    AgrupamentoEmpresasComponent,
    GrupoProducaoComponent,
    LancamentoManualFilterComponent,
    LancamentoManualComponent
  ],
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatTabsModule,
    ContainerModule,
    LancamentoManualTableComponentModule
    ],
  exports: [
    ProdutosComponent,
    LancamentoManualFilterComponent
  ]
})
export class PagesModule { }
