interface FileUploadRelease {
 DT_CTBIL:string;
 SG_EMPRE:string;
 CD_CANAL_VENDA:number;
 CD_PRODUTO:number;
 CD_LOCAL_DEBITO:number;
 CD_LOCAL_CREDITO:number;
 VL_PREMT:number;
 QT_PREMT:number;
 CD_CNAPE:number
}

