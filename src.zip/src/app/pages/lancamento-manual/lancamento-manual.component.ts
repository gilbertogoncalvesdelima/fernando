import { Component, Inject } from '@angular/core';
import * as XLSX from 'xlsx';
import { ManualPostingsService } from './service/manual-posting.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { LancamentoManualFilterService } from './lancamento-manual-filter/service/lancamento-manual-filter.service';

@Component({
  selector: 'app-lancamento-manual',
  templateUrl: './lancamento-manual.component.html',
  styleUrls: ['./lancamento-manual.component.scss']
})
export class LancamentoManualComponent {

  constructor(private manualPostingsService: ManualPostingsService, private dialog: MatDialog, private lancamentoManualFilterService: LancamentoManualFilterService) { }
  stateImport: any
  uploadfile(ev: any): void {
    let workBook: any = null;
    let jsonData: any[] = [];
    const reader = new FileReader();
    const file = ev.target.files[0];
    //upload
    reader.onload = (event) => {
      const data = reader.result;

      // Lê o conteúdo do arquivo XLSX
      workBook = XLSX.read(data, { type: 'binary' });

      // Itera sobre todas as abas (SheetNames) da planilha
      workBook.SheetNames.forEach((name: string) => {
        const sheet = workBook.Sheets[name];

        // Converte cada aba em um array de objetos e concatena no array principal
        const sheetData = XLSX.utils.sheet_to_json(sheet);
        jsonData = jsonData.concat(sheetData);
      });

      // Aqui você pode enviar os dados para o serviço
      const cargaConvertida = jsonData.map(data => ({ ...this.convertToCamelCase(data), "cdUsuroUltmaAlter": "T808835" }))
      this.stateImport = structuredClone(cargaConvertida);

      const dialogRef = this.dialog.open(DialogConfirmImportMassa);
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.submitCargaLancamentoManual(this.stateImport);
        }
      });
    };
    reader.readAsBinaryString(file);
  }

  private convertData(data: string) {
    return data.split('/').reverse().join('-');
  }

  convertToCamelCase(data: any): any {
    // Mapeamento de campos em UPPER_SNAKE_CASE para camelCase
    const keyMapping: { [key: string]: string } = {
      DT_CTBIL: 'dtCtbil',
      SG_EMPRE: 'sgEmpre',
      CD_CANAL_VENDA: 'cdCanalVenda',
      CD_PRODUTO: 'cdProduto',
      CD_LOCAL_DEBITO: 'cdLocalDebito',
      CD_LOCAL_CREDITO: 'cdLocalCredito',
      VL_PREMT: 'vlPremt',
      QT_PREMT: 'qtPremt',
      CD_CNAPE: 'cdCnape',
      CD_USURO_ULTMA_ALTER: 'cdUsuroUltmaAlter'
    };

    // Criação de um novo objeto com as chaves convertidas
    const convertedData: any = {};

    Object.keys(data).forEach((key) => {
      const newKey = keyMapping[key] || key; // Verifica se a chave precisa ser convertida
      convertedData[newKey] = key !== 'DT_CTBIL' ? data[key] : this.convertData(data[key]); // Copia o valor para a nova chave
    });

    return convertedData;
  }

  submitCargaLancamentoManual(carga: any[]) {
    console.log(carga);
    this.lancamentoManualFilterService.lancamentoManualLoading = true;

    this.manualPostingsService.postCargaLancamentoManual(carga).subscribe(
      succ => {
        console.log(succ)
        this.lancamentoManualFilterService.lancamentoManualLoading = false;
        this.stateImport = null;
        const dialogRef = this.dialog.open(DialogResultImportMassa, {
          data: { retorno: succ },
        });

      }, err => {
        console.log(err)
        const dialogRef = this.dialog.open(DialogResultImportMassa, {
          data: { retorno: err },
        });
        this.lancamentoManualFilterService.lancamentoManualLoading = false;
      })
  }
}


@Component({
  selector: 'dialog-result-import',
  template: '<span> {{ data.retorno }} </span>',
})
export class DialogResultImportMassa {
  constructor(
    public dialogRef: MatDialogRef<DialogResultImportMassa>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
}


@Component({
  selector: 'dialog-confirm-import',
  template: `
  <div mat-dialog-content>
  <p>Confirmar envio de dados? </p>
</div>
<div mat-dialog-actions>
  <button mat-button (click)="onNoClick()">Cancelar</button>
  <button mat-button [mat-dialog-close]="true" cdkFocusInitial>Ok</button>
</div>`,
})
export class DialogConfirmImportMassa {
  constructor(
    public dialogRef: MatDialogRef<DialogConfirmImportMassa>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
