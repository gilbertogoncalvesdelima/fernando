import { Component } from '@angular/core';

@Component({
  selector: 'app-lancamento-manual',
  templateUrl: './lancamento-manual.component.html',
  styleUrls: ['./lancamento-manual.component.scss']
})
export class LancamentoManualComponent {

}
