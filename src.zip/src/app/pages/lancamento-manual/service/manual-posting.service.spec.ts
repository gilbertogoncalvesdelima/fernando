import { TestBed } from '@angular/core/testing';

import { ManualPostingService } from './manual-posting.service';

describe('ManualPostingService', () => {
  let service: ManualPostingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManualPostingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
