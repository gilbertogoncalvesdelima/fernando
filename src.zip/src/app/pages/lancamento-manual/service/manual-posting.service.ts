import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ManualPostingsService {
  private apiUrl = 'http://localhost:8081/gestaoapolice/comissao/api/provisao/carga-lancamento-manual/carga';

  constructor(private http: HttpClient) { }

  postCargaLancamentoManual(carga: any[]): Observable<any> {
    const params = new HttpParams()
    return this.http.post<any>(this.apiUrl, carga, { params }); // Envia a requisição GET para a API com os parâmetros de paginação
  }
}
