import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LancamentoManualTableComponent } from './lancamento-manual-table.component';

describe('LancamentoManualTableComponent', () => {
  let component: LancamentoManualTableComponent;
  let fixture: ComponentFixture<LancamentoManualTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LancamentoManualTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LancamentoManualTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
