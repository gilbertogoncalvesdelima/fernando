import { CommonModule } from '@angular/common';
import { Component, NgModule, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { LancamentoManualFilterService } from '../lancamento-manual-filter/service/lancamento-manual-filter.service';
import { MatPaginatorModule } from '@angular/material/paginator';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatDialogContent, MatDialogModule, MatDialogTitle } from '@angular/material/dialog';


interface DataItem {
  emp: string;
  data: string;
  valor: string;
  tp: string;
  agencia: string;
  produto: string;
  grupo: string;
  cenape: string;
  quantidade: number;
  ultimasAlteracoes: string
}

@Component({
  selector: 'app-lancamento-manual-table',
  templateUrl: './lancamento-manual-table.component.html',
  styleUrls: ['./lancamento-manual-table.component.scss']
})
export class LancamentoManualTableComponent {
  displayedColumns: string[] = [
    'emp',
    'data',
    'valor',
    'tp',
    'agencia',
    'produto',
    'grupo',
    'cenape',
    'quantidade',
    'ultimasAlteracoes'
  ];

  dataSource = new MatTableDataSource<DataItem>([]);
  totalizadores!: {
    totalDebito: number,
    totalCredito: number
  };

  isLoading = false;

  @ViewChild(MatSort) sort!: MatSort;

  constructor(private lancamentoManualFilterService: LancamentoManualFilterService) {
    lancamentoManualFilterService.lancamentoManualState.subscribe(lanc => {
      this.dataSource.data = lanc;
    })

    lancamentoManualFilterService.lancamentoManualLoading.subscribe(loading => {
      this.isLoading = loading;
    })

    lancamentoManualFilterService.lancamentoManualTotalizadoresState.subscribe(lanc => {
      this.totalizadores = lanc;
    })

    lancamentoManualFilterService.lancamentoManualFilter.subscribe(filterField => {
      this.dataSource.filterPredicate = (data: DataItem, filter: string) => {
        const filterValue = filter.trim().toLowerCase();
        return Object.values(data).some(value => {
          return value != null && value.toString().toLowerCase().includes(filterValue);
        });
      };
      this.dataSource.filter = filterField.trim().toLowerCase();
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    })
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }
}


@NgModule({
  declarations: [LancamentoManualTableComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatSortModule,
    MatCardModule,
    MatDialogModule,
    MatPaginatorModule,
    FormsModule,
  ],
  exports: [LancamentoManualTableComponent],
})
export class LancamentoManualTableComponentModule { }
