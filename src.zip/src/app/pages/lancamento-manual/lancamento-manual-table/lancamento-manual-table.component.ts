import { CommonModule } from '@angular/common';
import { Component, NgModule, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatSort, MatSortModule } from '@angular/material/sort';


interface DataItem {
  emp: string;
  data: string;
  valor: string;
  tp: string;
  agencia: string;
  produto: string;
  grupo: string;
  cenape: string;
  quantidade: number;
  ultimasAlteracoes: string
}

@Component({
  selector: 'app-lancamento-manual-table',
  templateUrl: './lancamento-manual-table.component.html',
  styleUrls: ['./lancamento-manual-table.component.scss']
})
export class LancamentoManualTableComponent {
  displayedColumns: string[] = [
    'emp',
    'data',
    'valor',
    'tp',
    'agencia',
    'produto',
    'grupo',
    'cenape',
    'quantidade',
    'ultimasAlteracoes'
  ];

  dataSource = new MatTableDataSource<DataItem>([
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10 , ultimasAlteracoes: '2024-12-01'},
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15 ,  ultimasAlteracoes: '2024-12-01'},
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7 ,  ultimasAlteracoes: '2024-12-01'},
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10,  ultimasAlteracoes: '2024-12-01' },
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15,  ultimasAlteracoes: '2024-12-01' },
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7,  ultimasAlteracoes: '2024-12-01' },
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10,  ultimasAlteracoes: '2024-12-01' },
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15,  ultimasAlteracoes: '2024-12-01' },
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7,  ultimasAlteracoes: '2024-12-01' },
    { emp: '001', data: '2024-12-01', valor: '100,00', tp: 'Crédito', agencia: '001', produto: 'A', grupo: 'G1', cenape: '123', quantidade: 10,  ultimasAlteracoes: '2024-12-01' },
    { emp: '002', data: '2024-12-03', valor: '250,00', tp: 'Débito', agencia: '005', produto: 'B', grupo: 'G2', cenape: '456', quantidade: 15,  ultimasAlteracoes: '2024-12-01' },
    { emp: '003', data: '2024-12-02', valor: '75,00', tp: 'Crédito', agencia: '002', produto: 'C', grupo: 'G3', cenape: '789', quantidade: 7,  ultimasAlteracoes: '2024-12-01' },
  ]);

  @ViewChild(MatSort) sort!: MatSort;

  searchValue: string = '';
  mesAno: string = '';
  cnap: string = '';
  situacao: string = '';

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  applySpecificFilters() {
    this.dataSource.filterPredicate = (data: DataItem, filter: string) => {
      const mesAnoMatch = this.mesAno ? data.data.startsWith(this.mesAno) : true;
      const cnapMatch = this.cnap ? data.cenape.includes(this.cnap) : true;
      const situacaoMatch = this.situacao
        ? data.produto.toLowerCase().includes(this.situacao.toLowerCase())
        : true;
      return mesAnoMatch && cnapMatch && situacaoMatch;
    };
    this.dataSource.filter = JSON.stringify({
      mesAno: this.mesAno,
      cnap: this.cnap,
      situacao: this.situacao.toLowerCase(),
    });
  }

  applyGlobalSearch() {
    this.dataSource.filterPredicate = (data: DataItem, filter: string) =>
      Object.values(data).some((value) =>
        value.toString().toLowerCase().includes(filter)
      );
    this.dataSource.filter = this.searchValue.trim().toLowerCase();
  }
  }


@NgModule({
declarations: [LancamentoManualTableComponent],
imports: [
  CommonModule,
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatTableModule,
  MatSortModule,
  MatCardModule,
  FormsModule,
],
exports: [LancamentoManualTableComponent],
})
export class LancamentoManualTableComponentModule {}
