import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LancamentoManualFilterService {
  private _lancamentoManualState: Subject<any> = new Subject<any>();
  private _lancamentoManualFilter: Subject<any> = new Subject<any>();

  private apiUrl = 'http://localhost:8081/gestaoapolice/comissao/api/provisao/lancamento-manual';

  get lancamentoManualState(): Subject<any> {
    return this._lancamentoManualState;
  }

  set lancamentoManualState(state: any) {
    this._lancamentoManualState.next(structuredClone(state))
  }

  get lancamentoManualFilter(): Subject<any> {
    return this._lancamentoManualFilter;
  }

  set lancamentoManualFilter(filter: any) {
    this._lancamentoManualFilter.next(filter)
  }

  constructor(private http: HttpClient) { }

  // Realiza uma requisição GET para buscar os tipos de produtos com suporte a paginação
  getLancamentoManual(dataAlteracao: string, codigoNAC: string, lancamentoProcessado: string) {
    let params = new HttpParams()

    if (dataAlteracao) {
      params = params.append('dataAlteracao', dataAlteracao); // Adiciona sem substituir
    }

    if (codigoNAC) {
      params = params.append('codigoNAC', codigoNAC.toString()); // Adiciona sem substituir
    }

    if (lancamentoProcessado) {
      params = params.append('lancamentoProcessado', lancamentoProcessado); // Adiciona sem substituir
    }

    this.http.get<any>(this.apiUrl, { params }).subscribe(succ => {
      this.lancamentoManualState = structuredClone(succ);
    });
  }
}
