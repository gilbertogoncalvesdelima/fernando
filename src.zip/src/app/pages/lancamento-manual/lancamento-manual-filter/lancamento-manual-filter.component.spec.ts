import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LancamentoManualFilterComponent } from './lancamento-manual-filter.component';

describe('LancamentoManualFilterComponent', () => {
  let component: LancamentoManualFilterComponent;
  let fixture: ComponentFixture<LancamentoManualFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LancamentoManualFilterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LancamentoManualFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
