import { CommonModule } from '@angular/common';
import { Component, NgModule, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { LancamentoManualFilterService } from './service/lancamento-manual-filter.service';

interface DataItem {
  emp: string;
  data: string;
  valor: string;
  tp: string;
  agencia: string;
  produto: string;
  grupo: string;
  cenape: string;
  quantidade: number;
}

@Component({
  selector: 'app-lancamento-manual-filter',
  templateUrl: './lancamento-manual-filter.component.html',
  styleUrls: ['./lancamento-manual-filter.component.scss']
})
export class LancamentoManualFilterComponent {
  searchValue: string = '';
  mesAno: string = '05/2020';
  cnap: string = '106472';
  situacao: string = 'P';

  constructor(private lancamentoManualFilterService: LancamentoManualFilterService) {

  }

  applySpecificFilters() {

    this.lancamentoManualFilterService.getLancamentoManual(this.mesAno, this.cnap, this.situacao.toUpperCase())
    // faz pesquisa no service
  }

  applyGlobalSearch() {
    this.lancamentoManualFilterService.lancamentoManualFilter = this.searchValue
    // this.dataSource.filterPredicate = (data: DataItem, filter: string) =>
    //   Object.values(data).some((value) =>
    //     value.toString().toLowerCase().includes(filter)
    //   );
    // this.dataSource.filter = this.searchValue.trim().toLowerCase();
    // faz o filter na variavel
  }
}

@NgModule({
  declarations: [LancamentoManualFilterComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatSortModule,
    MatCardModule,
    FormsModule,
  ],
  exports: [LancamentoManualFilterComponent],
})
export class LancamentoManualFilterComponentModule { }
