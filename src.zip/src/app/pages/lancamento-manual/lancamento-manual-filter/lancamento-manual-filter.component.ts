import { Component } from '@angular/core';

@Component({
  selector: 'app-lancamento-manual-filter',
  templateUrl: './lancamento-manual-filter.component.html',
  styleUrls: ['./lancamento-manual-filter.component.scss']
})
export class LancamentoManualFilterComponent {

}
