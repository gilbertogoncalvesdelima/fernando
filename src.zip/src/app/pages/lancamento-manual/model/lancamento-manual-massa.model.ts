export interface LancamentoManualMassa {
  dtCtbil: string;
  sgEmpre: string;
  cdCanalVenda: number;
  cdProduto: number;
  cdLocalDebito: string;
  cdLocalCredito: string;
  vlPremt: number;
  qtPremt: number;
  cdCnape: string;
  cdUsuroUltmaAlter: string;
}
