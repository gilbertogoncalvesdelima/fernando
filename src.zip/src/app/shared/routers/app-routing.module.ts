import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//import { ManualPostingsComponent } from 'src/app/pages/lancamento-manual/lancamento-manual.component';
import { FechamentoMensalComponent } from 'src/app/pages/fechamento-mensal/fechamento-mensal.component';
import { LancamentoManualComponent } from 'src/app/pages/lancamento-mensal/lancamento-manual/lancamento-manual.component';
import { LancamentoProcessadoComponent } from 'src/app/pages/lancamento-mensal/lancamento-processado/lancamento-processado.component';
import { LancamentoTablesComponent } from 'src/app/pages/lancamento-mensal/lancamento-tables.component';
import { ProdutosComponent } from 'src/app/pages/produtos/produtos.component';

const routes: Routes = [
  { path: '', redirectTo: 'produtos', pathMatch: 'full' },
  { path: 'produtos', component: ProdutosComponent },
  { path: 'fechamento-mensal', component: FechamentoMensalComponent },
  { path: 'lancamento-manual', component: LancamentoProcessadoComponent },
  { path: '**', redirectTo: 'produtos' } // Rota coringa para 404
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
