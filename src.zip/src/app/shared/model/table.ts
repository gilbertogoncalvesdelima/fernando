export interface TableColumn {
  label: string;
  property: string;
  textAlignment?: string;
}
